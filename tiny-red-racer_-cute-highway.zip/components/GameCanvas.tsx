
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { GameState, Vector2, Entity, LevelData } from '../types';
import { CANVAS_WIDTH, CANVAS_HEIGHT, PLAYER_RADIUS, TAIL_SEGMENTS, PLAYER_MAX_HEALTH, INVINCIBILITY_DURATION, INITIAL_DASH_DURATION } from '../constants';

interface GameCanvasProps {
  gameState: GameState;
  level: LevelData;
  onGameOver: (score: number) => void;
  onLevelComplete: (score: number) => void;
  onUpdateHUD: (health: number, progress: number, score: number, isInvincible: boolean, distanceRemaining: number) => void;
}

const GameCanvas: React.FC<GameCanvasProps> = ({ 
  gameState, 
  level, 
  onGameOver, 
  onLevelComplete,
  onUpdateHUD
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();
  
  // Game State Refs
  const playerPos = useRef<Vector2>({ x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT - 150 });
  const playerHealth = useRef(PLAYER_MAX_HEALTH);
  const entities = useRef<Entity[]>([]);
  const distanceCovered = useRef(0);
  const score = useRef(0);
  const lastTime = useRef<number>(0);
  const keys = useRef<{ [key: string]: boolean }>({});
  const tailHistory = useRef<Vector2[]>([]);
  const frameCount = useRef(0);
  const invincibleUntil = useRef<number>(0);
  const dashUntil = useRef<number>(0);

  // Initialize Level
  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      playerPos.current = { x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT - 150 };
      playerHealth.current = PLAYER_MAX_HEALTH;
      entities.current = [];
      distanceCovered.current = 0;
      score.current = 0;
      
      const startTime = performance.now();
      lastTime.current = startTime;
      
      // Starting Dash: 2 seconds of invincibility and speed
      invincibleUntil.current = startTime + INITIAL_DASH_DURATION;
      dashUntil.current = startTime + INITIAL_DASH_DURATION;
      
      tailHistory.current = Array(TAIL_SEGMENTS).fill({ ...playerPos.current });
    }
  }, [gameState, level]);

  // Input Handling
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { keys.current[e.code] = true; };
    const handleKeyUp = (e: KeyboardEvent) => { keys.current[e.code] = false; };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const spawnEntity = useCallback(() => {
    const id = Math.random().toString(36).substr(2, 9);
    const rand = Math.random();
    let type: Entity['type'] = 'OBSTACLE';
    
    const carColors = ['#f97316', '#a855f7', '#10b981', '#64748b', '#eab308', '#ec4899'];
    let color = carColors[Math.floor(Math.random() * carColors.length)];
    let radius = 18; 

    const remaining = level.length - distanceCovered.current;
    if (remaining < 800) return;

    if (rand > 0.985) {
      type = 'DASH'; // Nitro powerup
      color = '#06b6d4'; // Cyan
      radius = 16;
    } else if (rand > 0.97) {
      type = 'SHIELD';
      color = '#fbbf24'; 
      radius = 14;
    } else if (rand > 0.94) {
      type = 'HEALTH';
      color = '#ef4444'; 
      radius = 14;
    } else if (rand > 0.65) {
      type = 'NPC';
      color = '#38bdf8'; 
      radius = 18;
    }
    
    const channelMargin = (CANVAS_WIDTH - level.width) / 2;
    const x = channelMargin + Math.random() * level.width;
    
    const entity: Entity = {
      id,
      pos: { x, y: -100 },
      radius,
      type,
      color,
      speedY: type === 'NPC' ? level.speed + 4 : level.speed,
      speedX: type === 'NPC' ? (Math.random() - 0.5) * 4 : 0
    };
    
    entities.current.push(entity);
  }, [level, distanceCovered]);

  const update = useCallback((time: number) => {
    if (gameState !== GameState.PLAYING) return;
    const deltaTime = time - lastTime.current;

    const isCurrentlyDashing = time < dashUntil.current;
    const currentMoveSpeed = isCurrentlyDashing ? level.speed * 2.2 : level.speed;

    // 1. Move Player
    const pControlSpeed = 7.5;
    if (keys.current['ArrowLeft'] || keys.current['KeyA']) playerPos.current.x -= pControlSpeed;
    if (keys.current['ArrowRight'] || keys.current['KeyD']) playerPos.current.x += pControlSpeed;
    if (keys.current['ArrowUp'] || keys.current['KeyW']) playerPos.current.y -= pControlSpeed;
    if (keys.current['ArrowDown'] || keys.current['KeyS']) playerPos.current.y += pControlSpeed;

    const channelMargin = (CANVAS_WIDTH - level.width) / 2;
    playerPos.current.x = Math.max(channelMargin + PLAYER_RADIUS, Math.min(CANVAS_WIDTH - channelMargin - PLAYER_RADIUS, playerPos.current.x));
    playerPos.current.y = Math.max(PLAYER_RADIUS, Math.min(CANVAS_HEIGHT - PLAYER_RADIUS, playerPos.current.y));

    // Update Exhaust
    frameCount.current++;
    if (frameCount.current % (isCurrentlyDashing ? 1 : 3) === 0) {
      tailHistory.current.unshift({ ...playerPos.current, y: playerPos.current.y + 15 });
      if (tailHistory.current.length > TAIL_SEGMENTS) tailHistory.current.pop();
    }

    // 2. Spawn & Move Entities
    if (Math.random() < 0.04 * level.difficulty) {
      spawnEntity();
    }

    const isCurrentlyInvincible = time < invincibleUntil.current;

    for (let i = entities.current.length - 1; i >= 0; i--) {
      const e = entities.current[i];
      e.pos.y += (e.speedY || level.speed) + (isCurrentlyDashing ? (currentMoveSpeed - level.speed) : 0);
      e.pos.x += (e.speedX || 0);

      if (e.type === 'NPC') {
        if (e.pos.x < channelMargin + e.radius || e.pos.x > CANVAS_WIDTH - channelMargin - e.radius) {
          if (e.speedX) e.speedX *= -1;
        }
      }

      // 3. Collision Detection
      const dx = e.pos.x - playerPos.current.x;
      const dy = e.pos.y - playerPos.current.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < e.radius + PLAYER_RADIUS - 4) { 
        if (e.type === 'OBSTACLE' || e.type === 'NPC') {
          if (!isCurrentlyInvincible) {
            playerHealth.current -= 1;
            score.current = Math.max(0, score.current - 150);
          }
        } else if (e.type === 'HEALTH') {
          playerHealth.current = Math.min(PLAYER_MAX_HEALTH, playerHealth.current + 1);
          score.current += 300;
        } else if (e.type === 'SHIELD') {
          invincibleUntil.current = time + INVINCIBILITY_DURATION;
          score.current += 300;
        } else if (e.type === 'DASH') {
          invincibleUntil.current = time + 3000;
          dashUntil.current = time + 3000;
          score.current += 500;
        }
        entities.current.splice(i, 1);
      } else if (e.pos.y > CANVAS_HEIGHT + 200) {
        entities.current.splice(i, 1);
      }
    }

    // 4. Progress
    distanceCovered.current += currentMoveSpeed;
    score.current += isCurrentlyDashing ? 2 : 1;

    const progress = Math.min(1, distanceCovered.current / level.length);
    const remaining = Math.max(0, level.length - distanceCovered.current);
    onUpdateHUD(playerHealth.current, progress, score.current, isCurrentlyInvincible, remaining);

    if (playerHealth.current <= 0) {
      onGameOver(score.current);
    } else if (progress >= 1) {
      onLevelComplete(score.current);
    }
  }, [gameState, level, onGameOver, onLevelComplete, onUpdateHUD, spawnEntity]);

  const drawHeart = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number) => {
    ctx.beginPath();
    ctx.moveTo(x, y + size / 4);
    ctx.quadraticCurveTo(x, y, x + size / 4, y);
    ctx.quadraticCurveTo(x + size / 2, y, x + size / 2, y + size / 4);
    ctx.quadraticCurveTo(x + size / 2, y, x + size * 0.75, y);
    ctx.quadraticCurveTo(x + size, y, x + size, y + size / 4);
    ctx.quadraticCurveTo(x + size, y + size / 2, x + size / 2, y + size * 0.9);
    ctx.quadraticCurveTo(x, y + size / 2, x, y + size / 4);
    ctx.fill();
  };

  const drawVehicle = (ctx: CanvasRenderingContext2D, color: string, radius: number, isNPC: boolean) => {
    const carW = radius * 2;
    const carH = radius * 3;
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.roundRect(-carW/2 + 5, -carH/2 + 5, carW, carH, 8);
    ctx.fill();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(-carW/2, -carH/2, carW, carH, 8);
    ctx.fill();
    ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
    ctx.beginPath();
    ctx.roundRect(-carW/2 + 4, -carH/4, carW - 8, carH/2.5, 4);
    ctx.fill();
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(-carW/3, carH/2 - 2, 4, 0, Math.PI * 2);
    ctx.arc(carW/3, carH/2 - 2, 4, 0, Math.PI * 2);
    ctx.fill();
    if (isNPC) {
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.strokeRect(-carW/2 - 2, -carH/2 - 2, carW + 4, carH + 4);
    }
  };

  const draw = useCallback((ctx: CanvasRenderingContext2D, time: number) => {
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    const isCurrentlyInvincible = time < invincibleUntil.current;
    const isCurrentlyDashing = time < dashUntil.current;

    // Highway
    ctx.fillStyle = '#1e293b'; 
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Shoulders
    const channelMargin = (CANVAS_WIDTH - level.width) / 2;
    ctx.fillStyle = '#0f172a'; 
    ctx.fillRect(0, 0, channelMargin, CANVAS_HEIGHT);
    ctx.fillRect(CANVAS_WIDTH - channelMargin, 0, channelMargin, CANVAS_HEIGHT);
    
    // Road Marks
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 3;
    ctx.setLineDash([30, 60]);
    // The road marks must offset based on total distance covered
    ctx.lineDashOffset = -(distanceCovered.current % 90);
    ctx.beginPath();
    ctx.moveTo(CANVAS_WIDTH / 2, 0);
    ctx.lineTo(CANVAS_WIDTH / 2, CANVAS_HEIGHT);
    ctx.stroke();
    ctx.setLineDash([]);

    // Checkered Finish Line
    const distanceLeft = level.length - distanceCovered.current;
    if (distanceLeft < CANVAS_HEIGHT) {
      const finishY = playerPos.current.y - distanceLeft;
      if (finishY > -100 && finishY < CANVAS_HEIGHT + 100) {
        const boxSize = 25;
        const rows = 4;
        for (let row = 0; row < rows; row++) {
          for (let col = 0; col < level.width / boxSize; col++) {
            ctx.fillStyle = (row + col) % 2 === 0 ? 'white' : 'black';
            ctx.fillRect(channelMargin + col * boxSize, finishY + row * (boxSize/2), boxSize, boxSize/2);
          }
        }
        ctx.strokeStyle = '#ffff00';
        ctx.lineWidth = 6;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#ffff00';
        ctx.beginPath();
        ctx.moveTo(channelMargin, finishY);
        ctx.lineTo(CANVAS_WIDTH - channelMargin, finishY);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
    }

    // Draw Entities
    entities.current.forEach(e => {
      ctx.save();
      ctx.translate(e.pos.x, e.pos.y);
      
      if (e.type === 'HEALTH') {
          const bounce = Math.sin(time / 150) * 10;
          ctx.translate(0, bounce);
          ctx.fillStyle = '#ef4444';
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#ef4444';
          drawHeart(ctx, -e.radius, -e.radius, e.radius * 2);
      } else if (e.type === 'SHIELD') {
          ctx.rotate(time / 400);
          ctx.fillStyle = '#fbbf24';
          ctx.shadowBlur = 20;
          ctx.shadowColor = '#fbbf24';
          ctx.beginPath();
          for (let i = 0; i < 5; i++) {
            ctx.lineTo(Math.cos((i * 72 * Math.PI) / 180) * e.radius, Math.sin((i * 72 * Math.PI) / 180) * e.radius);
            ctx.lineTo(Math.cos(((i * 72 + 36) * Math.PI) / 180) * (e.radius / 1.8), Math.sin(((i * 72 + 36) * Math.PI) / 180) * (e.radius / 1.8));
          }
          ctx.closePath();
          ctx.fill();
      } else if (e.type === 'DASH') {
          // Nitro Bottle/Flash icon
          ctx.rotate(Math.sin(time/200)*0.2);
          ctx.fillStyle = '#06b6d4';
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#06b6d4';
          ctx.beginPath();
          ctx.roundRect(-8, -14, 16, 28, 4);
          ctx.fill();
          ctx.fillStyle = 'white';
          ctx.textAlign = 'center';
          ctx.font = 'bold 12px Arial';
          ctx.fillText('N', 0, 5);
      } else {
          drawVehicle(ctx, e.color, e.radius, e.type === 'NPC');
      }
      ctx.restore();
    });

    // Draw Player
    ctx.save();
    ctx.translate(playerPos.current.x, playerPos.current.y);
    
    if (isCurrentlyInvincible) {
      const shieldGlow = isCurrentlyDashing ? '#06b6d4' : '#fbbf24';
      ctx.shadowBlur = 30;
      ctx.shadowColor = shieldGlow;
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, PLAYER_RADIUS * 2.5, 0, Math.PI * 2);
      ctx.stroke();
    }

    if (isCurrentlyDashing) {
      // Speed streaks
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.5)';
      ctx.lineWidth = 2;
      for (let s = 0; s < 5; s++) {
        const sx = (Math.random() - 0.5) * 40;
        ctx.beginPath();
        ctx.moveTo(sx, 20);
        ctx.lineTo(sx, 100);
        ctx.stroke();
      }
    }

    const carW = PLAYER_RADIUS * 2;
    const carH = PLAYER_RADIUS * 3.2;
    
    // Tires
    ctx.fillStyle = '#000';
    ctx.fillRect(-carW/2 - 3, -carH/2 + 5, 4, 10);
    ctx.fillRect(carW/2 - 1, -carH/2 + 5, 4, 10);
    ctx.fillRect(-carW/2 - 3, carH/2 - 15, 4, 10);
    ctx.fillRect(carW/2 - 1, carH/2 - 15, 4, 10);

    // Player Red Car
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.roundRect(-carW/2, -carH/2, carW, carH, 10);
    ctx.fill();

    // Windshield
    ctx.fillStyle = '#991b1b';
    ctx.beginPath();
    ctx.roundRect(-carW/2 + 3, -carH/2 + 5, carW - 6, carH/3, 5);
    ctx.fill();

    // Spoiler
    ctx.fillStyle = '#7f1d1d';
    ctx.fillRect(-carW/2, carH/2 - 6, carW, 6);

    ctx.restore();

    // Exhaust Smoke
    tailHistory.current.forEach((t, i) => {
      const scale = 1 - (i / TAIL_SEGMENTS);
      const smokeColor = isCurrentlyDashing ? 'rgba(6, 182, 212, 0.4)' : 'rgba(255, 255, 255, 0.25)';
      ctx.fillStyle = smokeColor;
      ctx.beginPath();
      ctx.arc(t.x + (Math.sin(time/40 + i)*6), t.y, (isCurrentlyDashing ? 12 : 8) * scale, 0, Math.PI * 2);
      ctx.fill();
    });

  }, [level.width, level.difficulty, level.length, distanceCovered]);

  const loop = useCallback((time: number) => {
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) {
      update(time);
      draw(ctx, time);
    }
    lastTime.current = time;
    requestRef.current = requestAnimationFrame(loop);
  }, [update, draw]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(loop);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [loop]);

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-slate-900 overflow-hidden">
      <canvas 
        ref={canvasRef} 
        width={CANVAS_WIDTH} 
        height={CANVAS_HEIGHT}
        className="rounded-lg shadow-2xl border border-slate-700"
      />
    </div>
  );
};

export default GameCanvas;
