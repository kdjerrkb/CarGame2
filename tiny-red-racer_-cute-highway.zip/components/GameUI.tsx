
import React, { useEffect, useState } from 'react';
import { GameState, LevelData } from '../types';
import { LEVELS, PLAYER_MAX_HEALTH } from '../constants';

interface HUDProps {
  health: number;
  progress: number;
  score: number;
  levelTitle: string;
  isInvincible: boolean;
  distanceRemaining: number;
}

const Confetti: React.FC = () => {
  const [particles, setParticles] = useState<any[]>([]);

  useEffect(() => {
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#ffffff'];
    const p = Array.from({ length: 100 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: -10 - Math.random() * 20,
      size: 5 + Math.random() * 8,
      color: colors[Math.floor(Math.random() * colors.length)],
      delay: Math.random() * 3,
      duration: 2 + Math.random() * 3,
      angle: Math.random() * 360,
    }));
    setParticles(p);
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-40">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-sm animate-fall"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: `${p.size}px`,
            height: `${p.size / 2}px`,
            backgroundColor: p.color,
            transform: `rotate(${p.angle}deg)`,
            animation: `fall ${p.duration}s linear ${p.delay}s infinite`,
          }}
        />
      ))}
      <style>{`
        @keyframes fall {
          0% { transform: translateY(0vh) rotate(0deg); opacity: 1; }
          100% { transform: translateY(110vh) rotate(720deg); opacity: 0; }
        }
        .animate-fall {
          animation: fall linear forwards;
        }
      `}</style>
    </div>
  );
};

export const HUD: React.FC<HUDProps> = ({ health, progress, score, levelTitle, isInvincible, distanceRemaining }) => (
  <div className="absolute top-0 left-0 w-full p-4 pointer-events-none flex flex-col gap-2 z-10">
    <div className="flex justify-between items-start text-white font-bold drop-shadow-md">
      <div className="flex flex-col">
        <div className="text-xl tracking-wider uppercase font-black italic">{levelTitle}</div>
        <div className="flex gap-1.5 mt-2">
          {Array.from({ length: PLAYER_MAX_HEALTH }).map((_, i) => (
            <i 
              key={i} 
              className={`fas fa-heart text-lg transition-all duration-300 ${
                i < health 
                  ? 'text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.6)] scale-110' 
                  : 'text-slate-800 scale-90 opacity-40'
              }`}
            />
          ))}
        </div>
      </div>
      <div className="text-right">
        <div className="text-2xl text-yellow-400 font-mono italic">Score: {score.toLocaleString()}</div>
        <div className="text-xs text-cyan-300 font-mono mt-1 uppercase tracking-tighter">
          {Math.ceil(distanceRemaining / 10)}M to victory
        </div>
        {isInvincible && (
          <div className="mt-2 text-xs text-cyan-400 uppercase tracking-widest animate-pulse font-bold bg-cyan-900/40 px-3 py-1 rounded-full border border-cyan-400/30 inline-block">
            <i className="fas fa-bolt mr-1"></i> NITRO MODE
          </div>
        )}
      </div>
    </div>
    
    <div className="relative w-full h-2 bg-slate-800/50 rounded-full border border-slate-700/50 mt-4 backdrop-blur-sm group">
        <div 
            className="h-full bg-gradient-to-r from-red-600 to-yellow-500 rounded-full transition-all duration-300 ease-out shadow-[0_0_15px_rgba(239,68,68,0.6)]"
            style={{ width: `${progress * 100}%` }}
        />
        <div className="absolute top-1/2 -right-1 -translate-y-1/2 text-white animate-pulse">
          <i className="fas fa-flag-checkered text-slate-100 text-sm"></i>
        </div>
    </div>
  </div>
);

interface MenuProps {
  onStart: (levelId: number) => void;
  bestScore: number;
  unlockedLevel: number;
}

export const Menu: React.FC<MenuProps> = ({ onStart, bestScore, unlockedLevel }) => (
  <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-slate-900/95 backdrop-blur-md text-white p-6">
    <div className="mb-12 text-center">
        <div className="flex justify-center mb-6">
            <div className="relative">
              <i className="fas fa-car text-6xl text-red-500 animate-bounce"></i>
              <div className="absolute -top-4 -right-4 animate-pulse">
                <i className="fas fa-sparkles text-yellow-400 text-2xl"></i>
              </div>
            </div>
        </div>
        <h1 className="text-7xl font-black mb-2 tracking-tighter italic text-transparent bg-clip-text bg-gradient-to-r from-red-600 via-yellow-400 to-red-600 animate-gradient-x">
          TINY RACER
        </h1>
        <p className="text-slate-400 uppercase tracking-widest text-xs font-bold">The Great Highway Adventure</p>
    </div>

    <div className="grid grid-cols-2 gap-4 max-w-lg w-full mb-8">
        {LEVELS.map((level) => (
            <button
                key={level.id}
                disabled={level.id > unlockedLevel}
                onClick={() => onStart(level.id)}
                className={`group relative p-6 rounded-2xl border-2 transition-all flex flex-col items-center overflow-hidden
                    ${level.id <= unlockedLevel 
                        ? 'border-slate-700 bg-slate-800/80 hover:bg-slate-700 hover:border-yellow-500 hover:scale-105 shadow-xl' 
                        : 'border-slate-800 bg-slate-900 opacity-50 cursor-not-allowed'}`}
            >
                {level.id > unlockedLevel ? (
                  <i className="fas fa-lock text-slate-600 text-xl"></i>
                ) : (
                  <>
                    <span className="text-xs text-yellow-500 mb-1 font-black uppercase italic">Track {level.id}</span>
                    <span className="font-bold text-lg text-center leading-tight">{level.title}</span>
                  </>
                )}
            </button>
        ))}
    </div>

    <div className="text-slate-500 text-sm font-mono">
      RECORD: <span className="text-yellow-400 font-bold">{bestScore.toLocaleString()}</span>
    </div>
    
    <div className="mt-12 flex flex-col gap-4 text-slate-500 text-xs items-center uppercase tracking-widest font-bold">
        <div className="flex items-center gap-2"><kbd className="px-2 py-1 bg-slate-800 rounded">WASD</kbd> or <kbd className="px-2 py-1 bg-slate-800 rounded">ARROWS</kbd> TO STEER</div>
        <div className="flex gap-8 mt-2">
          <div className="flex items-center gap-2"><i className="fas fa-heart text-red-500"></i> Fuel Up</div>
          <div className="flex items-center gap-2"><i className="fas fa-bolt text-cyan-400"></i> Nitro Dash</div>
          <div className="flex items-center gap-2"><i className="fas fa-star text-yellow-500"></i> Shield</div>
        </div>
    </div>
  </div>
);

interface ResultProps {
  type: 'GAME_OVER' | 'LEVEL_COMPLETE';
  score: number;
  levelTitle: string;
  onRetry: () => void;
  onMenu: () => void;
  onNext?: () => void;
}

export const ResultOverlay: React.FC<ResultProps> = ({ type, score, levelTitle, onRetry, onMenu, onNext }) => (
  <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/90 backdrop-blur-2xl text-white">
    {type === 'LEVEL_COMPLETE' && <Confetti />}
    
    <div className="text-center mb-8 relative z-50">
        {type === 'LEVEL_COMPLETE' && (
          <div className="mb-6 animate-bounce">
            <i className="fas fa-trophy text-8xl text-yellow-400 drop-shadow-[0_0_30px_rgba(250,204,21,0.8)]"></i>
          </div>
        )}
        <h2 className={`text-6xl font-black mb-4 italic tracking-tighter ${type === 'GAME_OVER' ? 'text-red-500' : 'text-green-400'}`}>
            {type === 'GAME_OVER' ? 'TOTAL CRASH!' : 'VICTORY!'}
        </h2>
        <p className="text-slate-400 font-bold uppercase tracking-widest">{levelTitle}</p>
    </div>
    
    <div className="text-7xl font-black mb-12 text-white font-mono drop-shadow-lg relative z-50">
        {score.toLocaleString()}
    </div>

    <div className="flex flex-col gap-4 w-72 relative z-50">
        {type === 'LEVEL_COMPLETE' && onNext && (
            <button 
                onClick={onNext}
                className="w-full py-5 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 hover:to-orange-400 text-white font-black text-xl rounded-2xl transition-all flex items-center justify-center gap-3 shadow-2xl hover:scale-105 active:scale-95"
            >
                NEXT TRACK <i className="fas fa-arrow-right"></i>
            </button>
        )}
        <button 
            onClick={onRetry}
            className="w-full py-4 bg-red-600 hover:bg-red-700 text-white font-black rounded-2xl transition-all shadow-xl hover:scale-105 active:scale-95"
        >
            {type === 'GAME_OVER' ? 'TRY AGAIN' : 'REPLAY TRACK'}
        </button>
        <button 
            onClick={onMenu}
            className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-black rounded-2xl transition-all shadow-xl hover:scale-105 active:scale-95"
        >
            BACK TO GARAGE
        </button>
    </div>
  </div>
);
