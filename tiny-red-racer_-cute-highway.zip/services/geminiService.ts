
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getLevelHint(levelTitle: string, difficulty: number): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Give a very short, poetic, and encouraging one-sentence hint for a player about to start a level called "${levelTitle}" with difficulty ${difficulty} in a game about a minimalist red car driving through a cute world. Keep it under 15 words.`,
      config: {
        temperature: 0.8,
      }
    });
    return response.text?.trim() || "Eyes on the road, little racer.";
  } catch (error) {
    console.error("Gemini hint failed:", error);
    return "The open road awaits your spirit.";
  }
}
